Data-Structures-and-Algorithm-Analysis-in-C
===========================================

A good textbook by Mark Allen Weiss.
-------------------------------------------
I decide to make a review on this book and implement the data structures myself.<br/>
Reinventing a wheel is important training, especially for those who design a car.<br/>
Digesting CLRS might be too time-consuming, and inappropriate for a job-seeker like me.<br/>
This book will be a proper substitute.<br/>
Timestamp: 1399952708<br/>
